package com.cloud_models_classifier;

import com.cloud_models_classifier.cli.CommandLineRunner;
import com.cloud_models_classifier.gui.MainFrame;
import com.cloud_models_classifier.service.CloudClassifierService;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class CloudClassifier {

    public static void main(String[] args) {
        CloudClassifierService service = new CloudClassifierService();

        if (args.length > 0) {
            CommandLineRunner cli = new CommandLineRunner(service);
            cli.run(args);
            return;
        }

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            new MainFrame().setVisible(true);
        });
    }
}
