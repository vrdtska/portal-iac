package com.cloud_models_classifier.service;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TextPreprocessor {

    private static final Set<String> STOPWORDS = new HashSet<>(Arrays.asList(
            "a", "al", "algo", "algunas", "algunos", "ante", "antes", "como", "con", "contra",
            "cual", "cuando", "de", "del", "desde", "donde", "durante", "e", "el", "ella",
            "ellas", "ellos", "en", "entre", "era", "erais", "eran", "eras", "eres", "es",
            "esa", "esas", "ese", "eso", "esos", "esta", "estaba", "estas", "este", "esto",
            "estos", "estoy", "fue", "ha", "habia", "han", "has", "hasta", "hay", "la",
            "las", "le", "les", "lo", "los", "me", "mi", "mis", "mucho", "muchos", "muy",
            "nos", "nosotros", "o", "otra", "otras", "otro", "otros", "para", "pero", "poco",
            "por", "porque", "que", "quien", "quienes", "se", "sea", "sean", "segun", "ser",
            "si", "sido", "sobre", "son", "su", "sus", "suya", "suyas", "suyo", "suyos",
            "tambien", "tanto", "te", "tenemos", "tener", "tengo", "ti", "tiene", "tienen",
            "toda", "todas", "todo", "todos", "tu", "tus", "un", "una", "unas", "uno",
            "unos", "vosostros", "y", "ya"
    ));

    public List<String> preprocess(String text) {
        if (text == null || text.trim().isEmpty()) {
            return Collections.emptyList();
        }

        String normalized = Normalizer.normalize(text.toLowerCase(), Normalizer.Form.NFD);
        String withoutAccents = normalized.replaceAll("\\p{M}", "");
        String cleaned = withoutAccents.replaceAll("[^a-z0-9\\s]", " ");
        String[] rawTokens = cleaned.split("\\s+");

        List<String> filteredTokens = new ArrayList<>();
        for (String token : rawTokens) {
            String trimmed = token.trim();
            if (trimmed.length() >= 2 && !STOPWORDS.contains(trimmed)) {
                filteredTokens.add(stem(trimmed));
            }
        }

        return filteredTokens;
    }

    public String stem(String word) {
        if (word.length() <= 3) return word;

        if (word.endsWith("es") && word.length() > 4) {
            return word.substring(0, word.length() - 2);
        } else if (word.endsWith("s") && !word.endsWith("is") && !word.endsWith("us")) {
            return word.substring(0, word.length() - 1);
        }

        String[] suffixes = {"ando", "iendo", "acion", "mente", "idad", "ar", "er", "ir"};
        for (String suffix : suffixes) {
            if (word.endsWith(suffix) && (word.length() - suffix.length()) >= 3) {
                return word.substring(0, word.length() - suffix.length());
            }
        }

        return word;
    }

    public List<String> generateNGrams(List<String> tokens, int n) {
        List<String> nGrams = new ArrayList<>();
        for (int i = 0; i <= tokens.size() - n; i++) {
            StringBuilder sb = new StringBuilder();
            for (int j = 0; j < n; j++) {
                if (j > 0) sb.append(" ");
                sb.append(tokens.get(i + j));
            }
            nGrams.add(sb.toString());
        }
        return nGrams;
    }
}
